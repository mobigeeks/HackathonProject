package com.mobilions.fxonline;

import java.util.Arrays;
import java.util.Map;

import com.mobilions.fxservices.eventProcessor.DealEventProcessor;
import com.mobilions.fxservices.eventProcessor.QuoteEventProcessor;
import com.mobilions.fxservices.reportdata.CurrencyData;
import com.mobilions.fxservices.reportdata.CurrencyDataManagerMap;
import com.mobilions.fxservices.services.SimulationServices;
import com.mobilions.fxservices.utils.SharedPrefs;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class MainFragment extends Fragment{
	TableRow clickedrow;
	boolean clicked=false;
	TabRow[] tabArr;
	boolean curclicked=false;
	boolean pos1clicked=false;
	boolean pos2clicked=false;
	boolean ageclicked=false;
	boolean pnlclicked=false;
	boolean bookclicked=false;
	boolean mktclicked=false;
	TabLayout tabLayout;
	String[] curs={};
	TableLayout t;

	CurrencyData[] currencyData;
	CurrencyDataManagerMap dataManager;
	private boolean isAlive = true;
	private Typeface face;
	private Thread updateThread;
	private String riskCCY;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.mainfragment, container, false);


		t=(TableLayout) rootView.findViewById(R.id.table);
		dataManager = CurrencyDataManagerMap.getInstance();
		face=Typeface.createFromAsset(getActivity().getAssets(),"fonts/verdana-1361513441.ttf");
		Typeface boldface=Typeface.createFromAsset(getActivity().getAssets(),"fonts/tr-sah-verdana-bold-bold-1361520020.ttf");

		String[] curs = getResources().getStringArray(R.array.cur_array);
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(),
				android.R.layout.simple_spinner_item,curs);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		final TextView cur=(TextView) rootView.findViewById(R.id.TextView22);
		cur.setTypeface(boldface);
		cur.setTextSize(2, 12);
		OnClickListener l2=new OnClickListener() {

			@Override

			public void onClick(View arg0) {
				if(!curclicked){
					CompareCur c=new CompareCur();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					curclicked=true;
				}
				else if(curclicked){
					DisplaySortedArrayRev();
					curclicked=false;
				}
			}
		};
		cur.setOnClickListener(l2);

		final TextView pos=(TextView) rootView.findViewById(R.id.TextView23);
		pos.setTypeface(boldface);
		pos.setTextSize(2, 12);
		OnClickListener l3=new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(!pos1clicked){
					ComparePos c=new ComparePos();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					pos1clicked =true;

				}
				else if(pos1clicked){
					DisplaySortedArrayRev();
					pos1clicked=false;
				}
			}
		};
		pos.setOnClickListener(l3);

		final TextView pos$=(TextView) rootView.findViewById(R.id.pos$);
		pos$.setTypeface(boldface);
		pos$.setTextSize(2, 12);
		OnClickListener l4=new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(!pos2clicked){
					ComparePos2 c=new ComparePos2();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					pos2clicked =true;
				}
				else if(pos2clicked){
					DisplaySortedArrayRev();
					pos2clicked=false;
				}
			}
		};
		pos$.setOnClickListener(l4);

		final TextView age=(TextView) rootView.findViewById(R.id.TextView25);
		age.setTypeface(boldface);
		age.setTextSize(2, 12);
		OnClickListener l8=new OnClickListener() {
			int cntr=0;
			@Override
			public void onClick(View arg0) {
				if(!ageclicked){
					CompareAge c=new CompareAge();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					ageclicked =true;
				}
				else if(ageclicked){
					DisplaySortedArrayRev();
					ageclicked=false;
				}
			}
		};
		age.setOnClickListener(l8);

		final TextView pnl=(TextView) rootView.findViewById(R.id.pnl);
		pnl.setTypeface(boldface);
		pnl.setTextSize(2, 12);
		OnClickListener l5=new OnClickListener() {
			int cntr=0;
			@Override
			public void onClick(View arg0) {
				if(!pnlclicked){
					ComparePnl  c=new ComparePnl();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					pnlclicked =true;
				}
				else if(pnlclicked){
					DisplaySortedArrayRev();
					pnlclicked=false;
				}
			}
		};
		pnl.setOnClickListener(l5);

		final TextView book=(TextView) rootView.findViewById(R.id.textView27);
		book.setTypeface(boldface);
		book.setTextSize(2, 12);
		OnClickListener l6=new OnClickListener() {
			int cntr=0;
			@Override
			public void onClick(View arg0) {
				if(!bookclicked){
					CompareBook c=new CompareBook();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					bookclicked =true;
				}
				else if(bookclicked){
					DisplaySortedArrayRev();
					bookclicked=false;
				}
			}
		};
		book.setOnClickListener(l6);

		final TextView mkt=(TextView) rootView.findViewById(R.id.textView28);
		mkt.setTypeface(boldface);
		mkt.setTextSize(2, 12);
		OnClickListener l7=new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(!mktclicked){
					CompareMkt c=new CompareMkt();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					mktclicked =true;
				}
				else if(mktclicked){
					DisplaySortedArrayRev();
					mktclicked=false;
				}
			}
		};
		mkt.setOnClickListener(l7);

		Button risk = (Button)rootView.findViewById(R.id.riskFlat);
		risk.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(clickedrow == null){
					AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
					alertDialogBuilder.setTitle("Risk Flattening");
					alertDialogBuilder.setMessage("Please select a currency.");

					alertDialogBuilder.setNegativeButton("OK",new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,int id) {
							dialog.cancel();
						}
					});

					AlertDialog alertDialog = alertDialogBuilder.create();

					// show alert
					alertDialog.getWindow().setLayout(1000, 600);
					alertDialog.show();
					
				}else{
					TextView ccy = (TextView)clickedrow.getChildAt(0);
					riskCCY = ccy.getText().toString();
					flattenRisk();
				}
				
			}
			
		});
		startApp();
		return rootView;
	}

	TextView Createview(int weight){

		TextView tv1=new TextView(getActivity());
		tv1.setTypeface(face);
		LayoutParams llp1 = new TableRow.LayoutParams(0, LayoutParams.WRAP_CONTENT,weight);
		tv1.setLayoutParams(llp1);
		tv1.setPadding(0, 20, 0, 20);
		tv1.setGravity(Gravity.CENTER);
		tv1.setTextSize(2, 11);
		//tv1.setLayoutParams(llp1);
		return tv1;
	}

	private void setTextView(TextView view, Object value, String field){
		view.setText(value+"");
		//		if((field.equals("pos1") | field.equals("pos2"))&& (Double)value<0  ){
		//			view.setTextColor(Color.RED);
		//		}else if(field.equals("pnl")){
		//			if((Float)value<=0  )
		//				view.setTextColor(Color.RED);
		//			else
		//				view.setTextColor(Color.GREEN);
		//		}else{
		view.setTextColor(Color.WHITE);
		//		}
		if(field.equals("pnl")){
			if((Float)value<0  )
				view.setBackgroundColor(Color.RED);
			else
				view.setBackgroundColor(Color.GREEN);
			view.setTextColor(Color.BLACK);
		}
	}

	void DisplaySortedArray(){
		if(currencyData != null && currencyData.length >0){
			//TableLayout t=(TableLayout) findViewById(R.id.table);
			Log.i("No of currencies", currencyData.length+"");
			Log.i("No of rows: ", t.getChildCount()+"");
			for(int i=0;i<t.getChildCount();i++){
				TableRow tr=(TableRow) t.getChildAt(i);

				TextView tv=(TextView) tr.getChildAt(0);
				setTextView(tv, currencyData[i].getCurrency(), "cur");
				TextView tv1=(TextView) tr.getChildAt(1);
				double position = currencyData[i].getPosition()/1000000;
				setTextView(tv1, Math.round(position*100d)/100d, "pos1");
				TextView tv2=(TextView) tr.getChildAt(2);
				double basePosition = currencyData[i].getBasePositon()/1000000;
				setTextView(tv2, Math.round(basePosition*100d)/100d, "pos2");
				TextView tv3=(TextView) tr.getChildAt(3);
				long lastUpdate = currencyData[i].getLastUpdate();
				long age;
				if(lastUpdate > 0){
					age = Math.round((System.currentTimeMillis() - currencyData[i].getLastUpdate())/60000);
				}else{
					age = 0;
				}
				setTextView(tv3, age, "age");
				TextView tv4=(TextView) tr.getChildAt(4);
				setTextView(tv4, currencyData[i].getPnl(), "pnl");
				TextView tv5=(TextView) tr.getChildAt(5);
				setTextView(tv5, currencyData[i].getBookMidPrice(), "book");
				TextView tv6=(TextView) tr.getChildAt(6);
				setTextView(tv6, currencyData[i].getMarkateMidPrice(), "mkt");

			}
		}
	}

	void DisplaySortedArrayRev(){
		if(currencyData != null && currencyData.length >0){
			//TableLayout t=(TableLayout) findViewById(R.id.table);
			for(int i=0,j=t.getChildCount()-1;  i<t.getChildCount() && j>=0;  i++,j--){

				TableRow tr=(TableRow) t.getChildAt(i);

				TextView tv=(TextView) tr.getChildAt(0);
				setTextView(tv, currencyData[j].getCurrency(), "cur");
				TextView tv1=(TextView) tr.getChildAt(1);
				double position = currencyData[j].getPosition()/1000000;
				setTextView(tv1, Math.round(position*100d)/100d, "pos1");
				TextView tv2=(TextView) tr.getChildAt(2);
				double basePosition = currencyData[j].getBasePositon()/1000000;
				setTextView(tv2, Math.round(basePosition*100d)/100d, "pos2");
				TextView tv3=(TextView) tr.getChildAt(3);
				long lastUpdate = currencyData[j].getLastUpdate();
				long age;
				if(lastUpdate > 0){
					age = Math.round((System.currentTimeMillis() - currencyData[j].getLastUpdate())/60000);
				}else{
					age = 0;
				}
				setTextView(tv3, age, "age");
				TextView tv4=(TextView) tr.getChildAt(4);
				setTextView(tv4, currencyData[j].getPnl(), "pnl");
				TextView tv5=(TextView) tr.getChildAt(5);
				setTextView(tv5, currencyData[j].getBookMidPrice(), "book");
				TextView tv6=(TextView) tr.getChildAt(6);
				setTextView(tv6, currencyData[j].getMarkateMidPrice(), "mkt");

			}
		}
	}

	private void startApp(){

		//t=(TableLayout) findViewById(R.id.table);
		if(!isServiceRunning(SimulationServices.class)){
			Intent serviceIntent = new Intent(getActivity(), SimulationServices.class);
			//serviceIntent.putExtra("fileName", "input.csv");
			getActivity().startService(serviceIntent);
			Toast toast = Toast.makeText(getActivity(), "Services started..", Toast.LENGTH_LONG);
			toast.show();
		}
		
		updateThread = new Thread(new Runnable() {

			@Override
			public void run() {

				while(isAlive){
					getActivity().runOnUiThread(new Runnable() {

						@Override
						public void run() {
							updateUIData();
							DisplaySortedArray();
						}
					});
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						isAlive= false;
						e.printStackTrace();
					}
				}

			}
		});
		updateThread.start();

	}


	private void updateUIData(){
		//		currencyData = new CurrencyData[dataManager.getTotalCurrencies()];
		currencyData = getAllCurrencies();
		if(t != null && currencyData != null){
			int noOfRows = t.getChildCount();
			int newNoRows = currencyData.length;

			if(newNoRows > noOfRows){
				for(int i=noOfRows; i<newNoRows;i++){
					final TableRow tabr=new TableRow(getActivity());
					tabr.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View arg0) {
							if(clickedrow != null){
								clickedrow.setBackgroundResource(R.drawable.textview_black);
							}
							clickedrow=tabr;
							clicked=true;
							tabr.setBackgroundResource(R.drawable.textview_blue);//setBackgroundResource(R.drawable.black);
						}
					});

					TableLayout.LayoutParams lp = new TableLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);

					lp.setMargins(0, 5, 0, 5);
					tabr.setLayoutParams(lp);
					tabr.setPadding(0, 50, 0, 50);
					tabr.setBackgroundResource(R.drawable.textview_black);
					tabr.setWeightSum(16);


					TextView tv1=Createview(2);
					tabr.addView(tv1, 0);

					//LinearLayout.LayoutParams llp2=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
					TextView tv2=Createview(2);
					tabr.addView(tv2,1);

					//LinearLayout.LayoutParams llp3=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
					TextView tv3=Createview(2);
					tabr.addView(tv3,2);

					//LinearLayout.LayoutParams llp4=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 5);
					TextView tv4=Createview(2);
					tabr.addView(tv4,3);

					//LinearLayout.LayoutParams llp5=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 5);
					TextView tv5=Createview(2);
					tabr.addView(tv5,4);

					//LinearLayout.LayoutParams llp6=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
					TextView tv6=Createview(3);
					tabr.addView(tv6,5);

					//LinearLayout.LayoutParams llp7=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
					TextView tv7=Createview(3);
					tabr.addView(tv7,6);


					tabr.setClickable(true);
					tabr.setFocusable(true);
					tabr.setFocusableInTouchMode(true);

					t.addView(tabr);	
				}
			}
		}
	}

	private void destroy(){
		if(t != null){
			t.removeAllViews();
		}
		currencyData = null;
		dataManager.destroy();
	}

	private boolean isServiceRunning(Class<?> serviceClass) {
		ActivityManager manager = (ActivityManager) getActivity().getSystemService(Context.ACTIVITY_SERVICE);
		for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (serviceClass.getName().equals(service.service.getClassName())) {
				return true;
			}
		}
		return false;
	}

	private CurrencyData[] getAllCurrencies(){
		Map<String, CurrencyData> dataMap = SharedPrefs.load(getActivity().getApplicationContext());
		if(dataMap != null){
			Log.i("No of currencies: ", dataMap.size()+"");
			CurrencyData[] data = new CurrencyData[dataMap.size()];
			int count = 0;
			for(String key : dataMap.keySet()){
				data[count] = (CurrencyData) dataMap.get(key);
				count++;
			}
			return data;
		}
		return null;
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		isAlive = false;
		super.onDestroy();
	}
	
	private void offsetPosition() {
		if (dataManager != null) {
			if (dataManager.containsCurrency(riskCCY)){
				CurrencyData curData = dataManager.getCurrencyData(riskCCY);
				curData.setAvgBuyPrice(0);
				curData.setAvgSellPrice(0);
				curData.setBasePositon(0);
				curData.setBookMidPrice(0);
				curData.setPnl(0);
				curData.setPosition(0);
				curData.setTotalBuyPrice(0);
				curData.setTotalBuyQty(0);
				curData.setTotalSellPrice(0);
				curData.setTotalSellQty(0);
				curData.setLastUpdate(System.currentTimeMillis());
				//TODO should lastUpdate be modified
				SharedPrefs.save(getActivity().getApplicationContext(), dataManager.getDataSet());
			}
		}
	}
	
	private void resetExposure() {
		if (dataManager != null) {
			if (dataManager.containsCurrency(riskCCY)) {
				CurrencyData curData = dataManager.getCurrencyData(riskCCY);				
				curData.setPnl(0);
				curData.setMarkateMidPrice(curData.getBookMidPrice());
				curData.setLastUpdate(System.currentTimeMillis());
				SharedPrefs.save(getActivity().getApplicationContext(), dataManager.getDataSet());
				//TODO should lastUpdate be modified
			}
		}
	}

	private void flattenRisk(){
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
		alertDialogBuilder.setTitle("Risk Flattening");
		alertDialogBuilder.setMessage("Please select the appropriate option to flatten the risk.");

		// set positive button: Yes message
		alertDialogBuilder.setNegativeButton("Position",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog,int id) {
				offsetPosition();
				dialog.cancel();
			}
		});
		
		alertDialogBuilder.setNeutralButton("Exposure", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog,int id) {
				resetExposure();
				dialog.cancel();
			}
		});

		alertDialogBuilder.setPositiveButton("Cancel",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog,int id) {
				dialog.cancel();
			}
		});

		AlertDialog alertDialog = alertDialogBuilder.create();

		// show alert
		alertDialog.getWindow().setLayout(1000, 600);
		alertDialog.show();
	}
}
