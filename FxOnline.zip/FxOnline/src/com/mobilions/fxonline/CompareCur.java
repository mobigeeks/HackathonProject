package com.mobilions.fxonline;


import java.util.Comparator;

import com.mobilions.fxservices.reportdata.CurrencyData;

public class CompareCur implements Comparator<CurrencyData>{

	public int compare(CurrencyData o1, CurrencyData o2) {
		if(o1.getCurrency().compareTo(o2.getCurrency())>0)
			return 1;
		else if(o1.getCurrency().compareTo(o2.getCurrency())<0)
			return -1;
		else
			return 0;
	}
}
