package com.mobilions.fxonline;


import android.app.Activity;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
 
public class Splash extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
	
		
		
		
		
		Thread background = new Thread() {
            public void run() {
                 
                try {
                    
                    sleep(4000);
                     
               
                    Intent i=new Intent(getBaseContext(),MainActivity.class);
                    startActivity(i);
                    
                    finish();
                     
                } catch (Exception e) {
                 
                }
            }
        };
         
     
        background.start();
		
		
		
		
	}
	
}
