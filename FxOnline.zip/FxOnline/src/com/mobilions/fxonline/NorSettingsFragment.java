package com.mobilions.fxonline;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

public class NorSettingsFragment extends Fragment{

	String[] curs;
	String[] mkts;
	String[] ints;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.settingsfragment, container, false);
		final TextView switchStatus=(TextView) rootView.findViewById(R.id.curtext);

		curs = getResources().getStringArray(R.array.cur_array);
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity().getApplicationContext(),
				android.R.layout.simple_spinner_item,curs);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		Spinner spinner1 = (Spinner) rootView.findViewById(R.id.curspinner);
		spinner1.setAdapter(dataAdapter);
		
		spinner1.setOnItemSelectedListener(new DropdownListener());

		mkts = getResources().getStringArray(R.array.marketarray);
		ArrayAdapter<String> dataAdapter1 = new ArrayAdapter<String>(getActivity().getApplicationContext(),
				android.R.layout.simple_spinner_item,curs);
		dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		Spinner spinner2 = (Spinner) rootView.findViewById(R.id.marketspinner);
		spinner2.setAdapter(dataAdapter1);
		spinner2.setOnItemSelectedListener(new DropdownListener());
		
		
		
		
		ints = getResources().getStringArray(R.array.intarray);
		ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(getActivity().getApplicationContext(),
				android.R.layout.simple_spinner_item,curs);
		dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		Spinner spinner3 = (Spinner) rootView.findViewById(R.id.timeintspinner);
		spinner3.setAdapter(dataAdapter2);
		spinner3.setOnItemSelectedListener(new DropdownListener());
		
		
		
		
		

		Switch mySwitch = (Switch) rootView.findViewById(R.id.mySwitch);

		mySwitch.setChecked(true);

		OnCheckedChangeListener listener=new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

				// TODO Auto-generated method stub
				if(isChecked){
					//switchStatus.setText("Switch is currently ON");
				}else{
					//  switchStatus.setText("Switch is currently OFF");
				}

			}


		};

		mySwitch.setOnCheckedChangeListener(listener);
		//attach a listener to check for changes in state
		/*mySwitch.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			   @Override
			   public void onCheckedChanged(CompoundButton buttonView,
			     boolean isChecked) {

			    if(isChecked){
			     switchStatus.setText("Switch is currently ON");
			    }else{
			     switchStatus.setText("Switch is currently OFF");
			    }

			   }
			  });

		 */



		return rootView;
	}

}
