package com.mobilions.fxonline;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

import com.mobilions.fxservices.eventProcessor.CommonEventProcessor;
import com.mobilions.fxservices.reportdata.CurrencyData;
import com.mobilions.fxservices.reportdata.CurrencyDataManagerMap;
import com.mobilions.fxservices.utils.FieldSeparatedFileReader;

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

@SuppressWarnings("deprecation")
public class MainActivity extends AppCompatActivity {

	TableRow clickedrow;
	boolean clicked=false;
	CurrencyData[] currencyData;
	boolean curclicked=false;
	boolean pos1clicked=false;
	boolean pos2clicked=false;
	boolean ageclicked=false;
	boolean pnlclicked=false;
	boolean bookclicked=false;
	boolean mktclicked=false;
	TabLayout tabLayout;
	TableLayout t;
	AssetManager assets;
	CurrencyDataManagerMap dataManager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
	    setSupportActionBar(myToolbar);  
		
		assets = this.getAssets();
		dataManager = CurrencyDataManagerMap.getInstance();
	    
	    String[] curs = getResources().getStringArray(R.array.cur_array);
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item,curs);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		
		
		
		Spinner spinner1 = (Spinner) findViewById(R.id.spinner1);
		spinner1.setAdapter(dataAdapter);
		spinner1.setOnItemSelectedListener(new DropdownListener());
		
		/*tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        tabLayout.addTab(tabLayout.newTab().setText("Tab 1"));
        tabLayout.addTab(tabLayout.newTab().setText("Tab 2"));
        tabLayout.addTab(tabLayout.newTab().setText("Tab 3"));
        tabLayout.addTab(tabLayout.newTab().setText("Tab 4"));*/
		
		
		//initTabArr();
		
		Log.i("hdfj", "jhdsfhj");
		final TextView cur=(TextView) findViewById(R.id.TextView22);
		OnClickListener l2=new OnClickListener() {
		
			@Override
			
			public void onClick(View arg0) {
				if(!curclicked){
					CompareCur c=new CompareCur();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					curclicked=true;
				}
				else if(curclicked){
					DisplaySortedArrayRev();
					curclicked=false;
				}
			}
		};
		cur.setOnClickListener(l2);

		final TextView pos=(TextView) findViewById(R.id.TextView23);
		OnClickListener l3=new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(!pos1clicked){
					ComparePos c=new ComparePos();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					pos1clicked =true;

				}
				else if(pos1clicked){
					DisplaySortedArrayRev();
					pos1clicked=false;
				}
			}
		};
		pos.setOnClickListener(l3);

		final TextView pos$=(TextView) findViewById(R.id.pos$);
		OnClickListener l4=new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(!pos2clicked){
					ComparePos2 c=new ComparePos2();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					pos2clicked =true;
				}
				else if(pos2clicked){
					DisplaySortedArrayRev();
					pos2clicked=false;
				}
			}
		};
		pos$.setOnClickListener(l4);

		final TextView age=(TextView) findViewById(R.id.TextView25);
		OnClickListener l8=new OnClickListener() {
			int cntr=0;
			@Override
			public void onClick(View arg0) {
				if(!ageclicked){
					CompareAge c=new CompareAge();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					ageclicked =true;
				}
				else if(ageclicked){
					DisplaySortedArrayRev();
					ageclicked=false;
				}
			}
		};
		age.setOnClickListener(l8);

		final TextView pnl=(TextView) findViewById(R.id.pnl);
		OnClickListener l5=new OnClickListener() {
			int cntr=0;
			@Override
			public void onClick(View arg0) {
				if(!pnlclicked){
					ComparePnl  c=new ComparePnl();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					pnlclicked =true;
				}
				else if(pnlclicked){
					DisplaySortedArrayRev();
					pnlclicked=false;
				}
			}
		};
		pnl.setOnClickListener(l5);

		final TextView book=(TextView) findViewById(R.id.textView27);
		OnClickListener l6=new OnClickListener() {
			int cntr=0;
			@Override
			public void onClick(View arg0) {
				if(!bookclicked){
					CompareBook c=new CompareBook();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					bookclicked =true;
				}
				else if(bookclicked){
					DisplaySortedArrayRev();
					bookclicked=false;
				}
			}
		};
		book.setOnClickListener(l6);

		final TextView mkt=(TextView) findViewById(R.id.textView28);
		OnClickListener l7=new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(!mktclicked){
					CompareMkt c=new CompareMkt();
					Arrays.sort(currencyData, c);
					DisplaySortedArray();
					mktclicked =true;
				}
				else if(mktclicked){
					DisplaySortedArrayRev();
					mktclicked=false;
				}
			}
		};
		mkt.setOnClickListener(l7);
		
		startApp();
	}

	TextView Createview(int weight){

		TextView tv1=new TextView(this);
		LayoutParams llp1 = new TableRow.LayoutParams(0, LayoutParams.WRAP_CONTENT,weight);
		tv1.setLayoutParams(llp1);
		tv1.setPadding(0, 20, 0, 20);
		tv1.setGravity(Gravity.CENTER);
		//tv1.setLayoutParams(llp1);
		return tv1;
	}

	private void setTextView(TextView view, Object value, String field){
		view.setText(value+"");
		if((field.equals("pos1") | field.equals("pos2"))&& (Double)value<0  ){
			view.setTextColor(Color.RED);
		}else if(field.equals("pnl")){
			if((Float)value<=0  )
				view.setTextColor(Color.RED);
			else
				view.setTextColor(Color.GREEN);
		}else{
			view.setTextColor(Color.WHITE);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		int id = item.getItemId();


		if (id == R.id.action_favorite) {
			Intent myIntent = new Intent(MainActivity.this,
					SecondActivity.class);
			startActivity(myIntent);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	void DisplaySortedArray(){
		TableLayout t=(TableLayout) findViewById(R.id.table);
		for(int i=0;i<t.getChildCount();i++){
			TableRow tr=(TableRow) t.getChildAt(i);

			TextView tv=(TextView) tr.getChildAt(0);
			setTextView(tv, currencyData[i].getCurrency(), "cur");
			TextView tv1=(TextView) tr.getChildAt(1);
			double position = currencyData[i].getPosition()/1000000;
			setTextView(tv1, Math.round(position*100d)/100d, "pos1");
			TextView tv2=(TextView) tr.getChildAt(2);
			double basePosition = currencyData[i].getBasePositon()/1000000;
			setTextView(tv2, Math.round(basePosition*100d)/100d, "pos2");
			TextView tv3=(TextView) tr.getChildAt(3);
			long lastUpdate = currencyData[i].getLastUpdate();
			long age;
			if(lastUpdate > 0){
				age = Math.round((System.currentTimeMillis() - currencyData[i].getLastUpdate())/60000);
			}else{
				age = 0;
			}
			setTextView(tv3, age, "age");
			TextView tv4=(TextView) tr.getChildAt(4);
			setTextView(tv4, currencyData[i].getPnl(), "pnl");
			TextView tv5=(TextView) tr.getChildAt(5);
			setTextView(tv5, currencyData[i].getBookMidPrice(), "book");
			TextView tv6=(TextView) tr.getChildAt(6);
			setTextView(tv6, currencyData[i].getMarkateMidPrice(), "mkt");

		}
	}

	void DisplaySortedArrayRev(){
		TableLayout t=(TableLayout) findViewById(R.id.table);
		for(int i=0,j=t.getChildCount()-1;  i<t.getChildCount() && j>=0;  i++,j--){

			TableRow tr=(TableRow) t.getChildAt(i);

			TextView tv=(TextView) tr.getChildAt(0);
			setTextView(tv, currencyData[j].getCurrency(), "cur");
			TextView tv1=(TextView) tr.getChildAt(1);
			double position = currencyData[j].getPosition()/1000000;
			setTextView(tv1, Math.round(position*100d)/100d, "pos1");
			TextView tv2=(TextView) tr.getChildAt(2);
			double basePosition = currencyData[j].getBasePositon()/1000000;
			setTextView(tv2, Math.round(basePosition*100d)/100d, "pos2");
			TextView tv3=(TextView) tr.getChildAt(3);
			long lastUpdate = currencyData[j].getLastUpdate();
			long age;
			if(lastUpdate > 0){
				age = Math.round((System.currentTimeMillis() - currencyData[j].getLastUpdate())/60000);
			}else{
				age = 0;
			}
			setTextView(tv3, age, "age");
			TextView tv4=(TextView) tr.getChildAt(4);
			setTextView(tv4, currencyData[j].getPnl(), "pnl");
			TextView tv5=(TextView) tr.getChildAt(5);
			setTextView(tv5, currencyData[j].getBookMidPrice(), "book");
			TextView tv6=(TextView) tr.getChildAt(6);
			setTextView(tv6, currencyData[j].getMarkateMidPrice(), "mkt");

		}
	}

	private void startApp(){
		t=(TableLayout) findViewById(R.id.table);

		try{
			InputStreamReader reader = new InputStreamReader(assets.open("input.csv"));
			Log.i("Loader", "Opening file");
			FieldSeparatedFileReader fileReader = new FieldSeparatedFileReader(reader, ",", assets);
			String[] nextEvent;
			CommonEventProcessor eventProcessor = new CommonEventProcessor();
			while((nextEvent = fileReader.getNextLine()) != null){
				eventProcessor.processEvent(nextEvent);
				updateUIData();
				DisplaySortedArray();
				Thread.sleep(1000);
			}
		}catch(IOException e){
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void updateUIData(){
		currencyData = new CurrencyData[dataManager.getTotalCurrencies()];
		currencyData = (CurrencyData[]) dataManager.getAllCurrencies();
		if(t != null && currencyData != null){
			int noOfRows = t.getChildCount();
			int newNoRows = currencyData.length;

			if(newNoRows > noOfRows){
				for(int i=noOfRows; i<newNoRows;i++){
					final TableRow tabr=new TableRow(getBaseContext());
					tabr.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View arg0) {
							if(clickedrow != null){
								clickedrow.setBackgroundResource(R.drawable.textview_grey);;
							}
							clickedrow=tabr;
							clicked=true;
							tabr.setBackgroundResource(R.drawable.textview_blue);//setBackgroundResource(R.drawable.black);
						}
					});

					TableLayout.LayoutParams lp = new TableLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);

					lp.setMargins(0, 10, 0, 10);
					tabr.setLayoutParams(lp);
					tabr.setBackgroundResource(R.drawable.textview_black);
					tabr.setWeightSum(7);


					TextView tv1=Createview(1);
					tabr.addView(tv1, 0);

					//LinearLayout.LayoutParams llp2=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
					TextView tv2=Createview(1);
					tabr.addView(tv2,1);

					//LinearLayout.LayoutParams llp3=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
					TextView tv3=Createview(1);
					tabr.addView(tv3,2);

					//LinearLayout.LayoutParams llp4=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 5);
					TextView tv4=Createview(1);
					tabr.addView(tv4,3);

					//LinearLayout.LayoutParams llp5=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 5);
					TextView tv5=Createview(1);
					tabr.addView(tv5,4);

					//LinearLayout.LayoutParams llp6=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
					TextView tv6=Createview(1);
					tabr.addView(tv6,5);

					//LinearLayout.LayoutParams llp7=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
					TextView tv7=Createview(1);
					tabr.addView(tv7,6);


					tabr.setClickable(true);
					tabr.setFocusable(true);
					tabr.setFocusableInTouchMode(true);

					t.addView(tabr);	
				}
			}
		}
	}

}

