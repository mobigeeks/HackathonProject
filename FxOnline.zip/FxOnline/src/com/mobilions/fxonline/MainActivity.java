package com.mobilions.fxonline;



import android.os.Bundle;

import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

@SuppressWarnings("deprecation")
public class MainActivity extends AppCompatActivity {
	DrawerLayout mDrawerLayout;


	ListView mDrawerList;
	ActionBarDrawerToggle mDrawerToggle;

	String mTitle="";




	@Override
	protected void onCreate(Bundle savedInstanceState) {

/*
		Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
	    setSupportActionBar(myToolbar);  
		*/
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		FragmentManager fragmentManager = getSupportFragmentManager();
		Fragment fragment=new MainFragment();
		fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();
		
		mTitle = (String) getTitle();

		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		mDrawerList = (ListView) findViewById(R.id.drawer_list);

		mDrawerToggle = new ActionBarDrawerToggle( this,
				mDrawerLayout,
				//R.drawable.ic_drawer,
				R.string.drawer_open,
				R.string.drawer_close){

			/** Called when drawer is closed */
			public void onDrawerClosed(View view) {
//				getActionBar().setTitle(mTitle);
				getSupportActionBar().setTitle(mTitle);
				invalidateOptionsMenu();
			}

			/** Called when a drawer is opened */
			public void onDrawerOpened(View drawerView) {
				invalidateOptionsMenu();
			}
		};

		// Setting DrawerToggle on DrawerLayout
		mDrawerLayout.setDrawerListener(mDrawerToggle);

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(
				getBaseContext(),
				R.layout.drawer_list_item ,
				getResources().getStringArray(R.array.settings)
				);


		mDrawerList.setAdapter(adapter);
//		getActionBar().setHomeButtonEnabled(true);
//		getActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);


		mDrawerList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				String[] menu = getResources().getStringArray(R.array.settings);



				mTitle = menu[position];
				Bundle data = new Bundle();
				data.putInt("position", position);
				mDrawerLayout.closeDrawer(mDrawerList);
				Fragment fragment1=null;
				
				switch(position){
				case 0:
					 fragment1=new MainFragment();
					 break;
				case 1:
					fragment1=new NorSettingsFragment();
					break;
					
					
					
				}
				

				/*if (fragment != null) {
					FragmentManager fragmentManager = getSupportFragmentManager();
					fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();

					mDrawerList.setItemChecked(position, true);
					mDrawerList.setSelection(position);
					mDrawerLayout.closeDrawer(mDrawerList);

				} else {
					Log.e("MainActivity", "Error in creating fragment");
				}
				*/
				
				if (fragment1 != null) {
					FragmentManager fragmentManager = getSupportFragmentManager();
					fragmentManager.beginTransaction().replace(R.id.content_frame, fragment1).commit();

					mDrawerList.setItemChecked(position, true);
					mDrawerList.setSelection(position);
					mDrawerLayout.closeDrawer(mDrawerList);

				} else {
					Log.e("MainActivity", "Error in creating fragment");
				}
			}
		});

	}

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		mDrawerToggle.syncState();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (mDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}


	/*@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean drawerOpen = mDrawerLayout.isDrawerOpen(mDrawerList);

	menu.findItem(R.id.action_settings).setVisible(!drawerOpen);
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}*/
}



