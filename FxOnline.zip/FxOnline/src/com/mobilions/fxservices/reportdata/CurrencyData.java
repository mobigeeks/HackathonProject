package com.mobilions.fxservices.reportdata;

public class CurrencyData implements Cloneable{
	
	private String currency;
	
	private float markateMidPrice;
	
	private float bidPrice;
	
	private float askPrice;
	
	private double position;
	
	private double basePositon;
	
	private float pnl;
	
	private float bookMidPrice;
	
	private long lastUpdate;
	
	private double avgBuyPrice;
	
	private double avgSellPrice;
	
	private double totalBuyPrice;
	
	private double totalSellPrice;
	
	private double totalBuyQty;
	
	private double totalSellQty;
	
	public CurrencyData(String currency){
		this.currency = currency;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public float getMarkateMidPrice() {
		return markateMidPrice;
	}

	public void setMarkateMidPrice(float markateMidPrice) {
		this.markateMidPrice = Math.round(markateMidPrice*100000f)/100000f;
	}

	public float getBidPrice() {
		return bidPrice;
	}

	public void setBidPrice(float bidPrice) {
		this.bidPrice = Math.round(bidPrice*100000f)/100000f;
	}

	public float getAskPrice() {
		return askPrice;
	}

	public void setAskPrice(float askPrice) {
		this.askPrice = Math.round(askPrice*100000f)/100000f;
	}

	public double getPosition() {
		return position;
	}

	public void setPosition(double position) {
		this.position = Math.round(position*100d)/100d;
	}

	public double getBasePositon() {
		return basePositon;
	}

	public void setBasePositon(double basePositon) {
		this.basePositon = Math.round(basePositon*100d)/100d;
	}

	public float getPnl() {
		return pnl;
	}

	public void setPnl(float pnl) {
		this.pnl = Math.round(pnl*1000f)/1000f;
	}

	public float getBookMidPrice() {
		return bookMidPrice;
	}

	public void setBookMidPrice(float bookMidPrice) {
		this.bookMidPrice = Math.round(bookMidPrice*100000f)/100000f;
	}

	public long getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(long lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public double getAvgBuyPrice() {
		return avgBuyPrice;
	}

	public void setAvgBuyPrice(double avgBuyPrice) {
		this.avgBuyPrice = Math.round(avgBuyPrice*100000d)/100000d;
	}

	public double getAvgSellPrice() {
		return avgSellPrice;
	}

	public void setAvgSellPrice(double avgSellPrice) {
		this.avgSellPrice = Math.round(avgSellPrice*100000d)/100000d;
	}
	
	public double getTotalBuyPrice() {
		return totalBuyPrice;
	}

	public void setTotalBuyPrice(double totalBuyPrice) {
		this.totalBuyPrice = Math.round(totalBuyPrice*100000d)/100000d;
	}

	public double getTotalSellPrice() {
		return totalSellPrice;
	}

	public void setTotalSellPrice(double totalSellPrice) {
		this.totalSellPrice = Math.round(totalSellPrice*100000d)/100000d;
	}

	public double getTotalBuyQty() {
		return totalBuyQty;
	}

	public void setTotalBuyQty(double totalBuyQty) {
		this.totalBuyQty = totalBuyQty;
	}

	public double getTotalSellQty() {
		return totalSellQty;
	}

	public void setTotalSellQty(double totalSellQty) {
		this.totalSellQty = totalSellQty;
	}

	public int hashCode(){
		if(currency != null)
			return currency.hashCode();
		else
			return 0;
	}
	
	public boolean equals(Object obj){
		if(obj instanceof CurrencyData){
			CurrencyData curObj = (CurrencyData) obj;
			if(curObj.currency != null && curObj.currency.equals(this.currency)){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}

	@Override
	public String toString() {
		return "CurrencyData [currency=" + currency + ", markateMidPrice=" + markateMidPrice + ", bidPrice=" + bidPrice
				+ ", askPrice=" + askPrice + ", position=" + position + ", basePositon=" + basePositon + ", pnl=" + pnl
				+ ", bookMidPrice=" + bookMidPrice + ", lastUpdate=" + lastUpdate + ", avgBuyPrice=" + avgBuyPrice
				+ ", avgSellPrice=" + avgSellPrice + ", totalBuyPrice=" + totalBuyPrice + ", totalSellPrice="
				+ totalSellPrice + ", totalBuyQty=" + totalBuyQty + ", totalSellQty=" + totalSellQty + "]";
	}
	
}
