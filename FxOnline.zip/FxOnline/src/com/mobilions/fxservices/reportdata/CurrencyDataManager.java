package com.mobilions.fxservices.reportdata;

public interface CurrencyDataManager {

	void addCurrencyData(CurrencyData event);
	
	CurrencyData getCurrencyData(String currency);
	
	boolean containsCurrency(String currency);
	
	Object getAllCurrencies();
}
