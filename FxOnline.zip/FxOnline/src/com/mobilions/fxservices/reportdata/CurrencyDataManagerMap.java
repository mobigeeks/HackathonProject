package com.mobilions.fxservices.reportdata;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class CurrencyDataManagerMap implements CurrencyDataManager{

	private Map<String, CurrencyData> dataSet;
	
	private CurrencyDataManagerMap() {
		// TODO Auto-generated constructor stub
		dataSet = Collections.synchronizedMap(new HashMap<String, CurrencyData>());
	}
	
	private static CurrencyDataManagerMap instance;
	
	public static CurrencyDataManagerMap getInstance(){
		if(instance != null){
			return instance;
		}else{
			synchronized(CurrencyDataManagerSet.class){
				if(instance == null){
					instance = new CurrencyDataManagerMap();
				}
				return instance;
			}
		}
	}
	
	@Override
	public void addCurrencyData(CurrencyData event) {
		// TODO Auto-generated method stub
		if(dataSet != null){
			dataSet.put(event.getCurrency(), event);
		}
	}

	@Override
	public CurrencyData getCurrencyData(String currency) {
		// TODO Auto-generated method stub
		if(dataSet != null){
			return dataSet.get(currency);
		}else{
			return null;
		}
	}

	@Override
	public boolean containsCurrency(String currency) {
		// TODO Auto-generated method stub
		if(dataSet.containsKey(currency)){
			return true;
		}else{
			return false;
		}
	}

	@Override
	public Object getAllCurrencies() {
		// TODO Auto-generated method stub
		if(dataSet != null){
			CurrencyData[] data = new CurrencyData[dataSet.size()];
			int count = 0;
			for(String key : dataSet.keySet()){
				try {
					data[count] = (CurrencyData) dataSet.get(key).clone();
					count++;
				} catch (CloneNotSupportedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return data;
		}
		return null;
	}
	
	public int getTotalCurrencies(){
		if(dataSet != null){
			return dataSet.size();
		}else{
			return 0;
		}
	}

}
