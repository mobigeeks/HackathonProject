package com.mobilions.fxservices.reportdata;

import java.util.Collections;
import java.util.HashSet;

public class CurrencyDataManagerSet implements CurrencyDataManager{
	
	private HashSet<CurrencyData> dataSet;

	private CurrencyDataManagerSet(){
		dataSet = (HashSet<CurrencyData>) Collections.synchronizedSet(new HashSet<CurrencyData>());
	}
	
	private static CurrencyDataManagerSet instance;
	
	public static CurrencyDataManagerSet getInstance(){
		if(instance != null){
			return instance;
		}else{
			synchronized(CurrencyDataManagerSet.class){
				if(instance == null){
					instance = new CurrencyDataManagerSet();
				}
				return instance;
			}
		}
	}
	
	@Override
	public void addCurrencyData(CurrencyData event) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public CurrencyData getCurrencyData(String currency) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean containsCurrency(String currency) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object getAllCurrencies() {
		// TODO Auto-generated method stub
		if(dataSet != null){
			return dataSet.clone();
		}else{
			return null;
		}
	}

}
