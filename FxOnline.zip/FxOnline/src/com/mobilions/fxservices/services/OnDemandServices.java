package com.mobilions.fxservices.services;

import java.io.IOException;
import java.io.InputStreamReader;

import com.mobilions.fxservices.eventProcessor.CommonEventProcessor;
import com.mobilions.fxservices.reportdata.CurrencyDataManagerMap;
import com.mobilions.fxservices.utils.FieldSeparatedFileReader;
import com.mobilions.fxservices.utils.SharedPrefs;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.util.Log;
//Easiest way to implement Started Services - On-demand
public class OnDemandServices extends IntentService{
	private AssetManager assetMgr;
	private CurrencyDataManagerMap dataMap = CurrencyDataManagerMap.getInstance();
	public OnDemandServices() {
		super("OnDemandServices");
		//assetMgr = getApplicationContext().getAssets();
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		try{
			//String fileName = intent.getStringExtra("fileName");Do null check
			assetMgr = this.getApplicationContext().getAssets();
			InputStreamReader inStreamReader = new InputStreamReader(assetMgr.open("input.csv"));
			Log.i("OnDemandServices's onHandleIntent()", "Opening file...");
			FieldSeparatedFileReader fileReader = new FieldSeparatedFileReader(inStreamReader, ",", assetMgr);
			String[] event;
			CommonEventProcessor evtProcessor = new CommonEventProcessor();
			while((event = fileReader.getNextLine()) != null){
				evtProcessor.processEvent(event);
				SharedPrefs.save(getApplicationContext(), dataMap.getDataSet());
				Thread.sleep(1000);
			}
		}catch(IOException e){
			//Log.e("", "");
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
