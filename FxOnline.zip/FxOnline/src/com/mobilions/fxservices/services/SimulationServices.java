package com.mobilions.fxservices.services;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.mobilions.fxonline.MainActivity;
import com.mobilions.fxservices.eventProcessor.CommonEventProcessor;
import com.mobilions.fxservices.reportdata.CurrencyDataManagerMap;
import com.mobilions.fxservices.utils.FieldSeparatedFileReader;
import com.mobilions.fxservices.utils.SharedPrefs;

import android.R;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

public class SimulationServices extends Service{
	private final int foregroundNotificationId = 1;
	
	private ExecutorService executorService;
	private InputStreamReader inStreamReader;
	private FieldSeparatedFileReader fileReader;
	private CommonEventProcessor evtProcessor;
	private Notification foregroundNotification;
	private CurrencyDataManagerMap dataMap = CurrencyDataManagerMap.getInstance();
	
	
	@Override
	public void onCreate() {
		executorService = Executors.newSingleThreadExecutor();
		Log.i("SimulationServices onCreate()", "Opening file...");
		try {
			inStreamReader = new InputStreamReader(this.getApplicationContext().getAssets().open("input.csv"));
			fileReader = new FieldSeparatedFileReader(inStreamReader, ",", this.getApplicationContext().getAssets());
//			assetMgr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		runAsForegroundService();
		Log.i("SimulationServices onCreate()", "Done opening file...");
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		ServiceRunnable runnable = new ServiceRunnable(this, startId);
		executorService.execute(runnable);
		
		return Service.START_NOT_STICKY;
	}	

	@Override
	public void onDestroy() {
//		assetMgr.close();
		try {
			inStreamReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}
	
	void runAsForegroundService(){
		Intent mainActivityIntent = new Intent(this, MainActivity.class);
		PendingIntent pendingIntentMainAct= PendingIntent.getActivity(this, 0, mainActivityIntent, 0);
		
		foregroundNotification = new NotificationCompat.Builder(this)
				 .setContentTitle("Simulator Services")
				 .setTicker("Services starting..")
				 .setContentText("Getting quote and deal events")
				 .setSmallIcon(R.drawable.btn_dialog)
				 .setContentIntent(pendingIntentMainAct)
				 .setOngoing(true).build();
		startForeground(foregroundNotificationId, foregroundNotification);
	}
	
	
	class ServiceRunnable implements Runnable{
		private SimulationServices simulationServices;
		private int startId;
		public ServiceRunnable(SimulationServices sServices, int startId){
			this.simulationServices = sServices;
			this.startId = startId;
		}

		@Override
		public void run() {
			try{ 
				Log.i("SimulationServices onStartCommand()", "Doing work...");
				
				String[] event;
				evtProcessor = new CommonEventProcessor();
				/*while((event = fileReader.getNextLine()) != null){
					evtProcessor.processEvent(event);
					Thread.sleep(2000);
				}*/
				
				while((event = fileReader.getNextLine()) != null){
					evtProcessor.processEvent(event);
					SharedPrefs.save(getApplicationContext(), dataMap.getDataSet());
					Thread.sleep(1000);
				}
				stopForeground(true);
				simulationServices.stopSelfResult(startId);				
			}catch(IOException e){
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
}
