package com.mobilions.fxservices.services;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import com.mobilions.fxonline.MainActivity;
import com.mobilions.fxonline.R;
import com.mobilions.fxservices.eventProcessor.CommonEventProcessor;
import com.mobilions.fxservices.reportdata.CurrencyData;
import com.mobilions.fxservices.reportdata.CurrencyDataManagerMap;
import com.mobilions.fxservices.utils.FieldSeparatedFileReader;
import com.mobilions.fxservices.utils.Settings;
import com.mobilions.fxservices.utils.SharedPrefs;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

public class SimulationServices extends Service{
	private static final Logger logger = Logger.getLogger(SimulationServices.class.getName());
	private final int foregroundNotificationId = 1;	
	private ExecutorService executorService;
	private ScheduledExecutorService  scheduledService;
	private InputStreamReader inStreamReader;
	private FieldSeparatedFileReader fileReader;
	private CommonEventProcessor evtProcessor;
	private Notification foregroundNotification;
	private NotificationManager notificationMgr;
	private CurrencyDataManagerMap dataMap = CurrencyDataManagerMap.getInstance();
	
	
	@Override
	public void onCreate() {
		executorService = Executors.newSingleThreadExecutor();
		scheduledService = Executors.newSingleThreadScheduledExecutor();
		notificationMgr = (NotificationManager)this.getSystemService(Context.NOTIFICATION_SERVICE);
		Log.i("SimulationServices onCreate()", "Opening file...");
		try {
			inStreamReader = new InputStreamReader(this.getApplicationContext().getAssets().open("input.csv"));
			fileReader = new FieldSeparatedFileReader(inStreamReader, ",", this.getApplicationContext().getAssets());
		} catch (IOException e) {
			e.printStackTrace();
		}
		runAsForegroundService();
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		ServiceRunnable runnable = new ServiceRunnable(this, startId);
		executorService.execute(runnable);
		
		ScheduledRequest request = new ScheduledRequest(this, startId);
		scheduledService.scheduleAtFixedRate(request, 30, 60, TimeUnit.SECONDS) ;
		return Service.START_NOT_STICKY;
	}	

	@Override
	public void onDestroy() {
		try {
			inStreamReader.close();
			executorService.shutdown();
			scheduledService.shutdownNow();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}
	
	void runAsForegroundService(){
		Intent mainActivityIntent = new Intent(this, MainActivity.class);
		PendingIntent pendingIntentMainAct= PendingIntent.getActivity(this, 0, mainActivityIntent, 0);		
		foregroundNotification = new NotificationCompat.Builder(this)
				 .setContentTitle("InstaFX Simulator")
				 .setTicker("Services starting..")
				 .setContentText("Getting quote and deal events")
				 .setSmallIcon( R.drawable.anz)
				 .setContentIntent(pendingIntentMainAct)
				 .setOngoing(true).build();
		startForeground(foregroundNotificationId, foregroundNotification);
	}
	
	void sendAlerts(){
		Log.i("sendAlerts", "Check for alert cases");
		Set<Entry<String, CurrencyData>> dataSet = dataMap.getDataSet().entrySet();
		StringBuilder sb = new StringBuilder("PnL alerts: ");
		boolean flag = false;
		for(Entry<String, CurrencyData> entry : dataSet){
			CurrencyData ccyData = entry.getValue();
			if(ccyData.getPnl() > 0.1 || ccyData.getPnl() < -5.0){
				sb.append("Ccy=");sb.append(ccyData.getCurrency());
				sb.append("PnL=");sb.append(ccyData.getPnl());
				flag = true;
			}			
		}
		if(flag)
			updateStatus(R.drawable.anz, sb.toString());
	}
	
	void updateStatus(int iconId, String info){
		foregroundNotification.icon = iconId;
		foregroundNotification = new NotificationCompat.Builder(this)
				 .setContentTitle("ALERT! InstaFX Simulator")
				 .setTicker("Services running..")
				 .setContentText(info)
				 .setSmallIcon( R.drawable.anz)
				 .setOngoing(true).build();
		notificationMgr.notify(foregroundNotificationId, foregroundNotification);
	}
	
	class ServiceRunnable implements Runnable{
		private SimulationServices simulationServices;
		private int startId;
		public ServiceRunnable(SimulationServices sServices, int startId){
			this.simulationServices = sServices;
			this.startId = startId;
		}

		@Override
		public void run() {
			try{ 
				Log.i("run() ServiceRunnable", "Doing work...");
				String[] event;
				evtProcessor = new CommonEventProcessor();
				while((event = fileReader.getNextLine()) != null){
					evtProcessor.processEvent(event);
					SharedPrefs.save(getApplicationContext(), dataMap.getDataSet());					
					//Thread.sleep(1000);
				}
				stopForeground(true);
				simulationServices.stopSelfResult(startId);				
			}catch(IOException e){
				e.printStackTrace();
			}
		}
		
	}
	
	class ScheduledRequest implements Runnable{
		private SimulationServices simulationServices;
		private int startId;
		public ScheduledRequest(SimulationServices sServices, int startId){
			this.simulationServices = sServices;
			this.startId = startId;
		}

		@Override
		public void run() {
			if(Settings.notification)
				simulationServices.sendAlerts();
		}
		
	}
}
