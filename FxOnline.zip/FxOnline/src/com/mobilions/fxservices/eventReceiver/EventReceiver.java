package com.mobilions.fxservices.eventReceiver;

public interface EventReceiver {
	
	void receiveFxEvent();

}
