/**
 * 
 */
package com.mobilions.fxservices.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * @author Shreyas Trivedi
 *
 */
public class DatabaseManager extends SQLiteOpenHelper {
	
	public DatabaseManager(Context context){
	      super(context, AppConstants.DATABASE_NAME , null, 1);
	}

	/* (non-Javadoc)
	 * @see android.database.sqlite.SQLiteOpenHelper#onCreate(android.database.sqlite.SQLiteDatabase)
	 */
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		
	}
	
	public void createTable(){
		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(AppConstants.CREATE_SETTING_TABLE);
		Log.i("Setting", "Setting table created");
	}

	/* (non-Javadoc)
	 * @see android.database.sqlite.SQLiteOpenHelper#onUpgrade(android.database.sqlite.SQLiteDatabase, int, int)
	 */
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub

	}
	
	public boolean insertSettings(String quoteCCY, String mktVenue, int interval, int notification){
		
	    SQLiteDatabase db = this.getWritableDatabase();
	    
	    Cursor cr = getSettings();
	    if((cr != null) && cr.getCount() > 0){
			Log.i("Settings", "Setting already present in table. Not inserted.");
			return false;
		}else{
			ContentValues contentValues = new ContentValues();

			contentValues.put(AppConstants.COLUMN_CCY, quoteCCY);
			contentValues.put(AppConstants.COLUMN_MKT, mktVenue);
			contentValues.put(AppConstants.COLUMN_INTERVAL, interval);
			contentValues.put(AppConstants.COLUMN_NOTIFICATION, notification);

			db.insert(AppConstants.SETTING_TABLE_NAME, null, contentValues);
			return true;
		}
	}
	
	public Cursor getSettings(){
		SQLiteDatabase db = this.getReadableDatabase();
	    Cursor res =  db.rawQuery(AppConstants.SELECT_SETTING_TABLE,null);
	    return res;
	}
	
	public int numberOfRows(){
		try{
			SQLiteDatabase db = this.getReadableDatabase();
			int numRows = (int) DatabaseUtils.queryNumEntries(db, AppConstants.SETTING_TABLE_NAME);
			return numRows;
		}catch(Exception e){
			return 0;
		}
	}
	
	public boolean updateQuoteCCY(String ccy){
		SQLiteDatabase db = this.getWritableDatabase();
	    ContentValues contentValues = new ContentValues();
	    contentValues.put(AppConstants.COLUMN_CCY, ccy);
	    db.update(AppConstants.SETTING_TABLE_NAME, contentValues, null, null);
	    return true;
	}
	
	public boolean updateMktVenue(String mkt){
		SQLiteDatabase db = this.getWritableDatabase();
	    ContentValues contentValues = new ContentValues();
	    contentValues.put(AppConstants.COLUMN_MKT, mkt);
	    db.update(AppConstants.SETTING_TABLE_NAME, contentValues, null, null);
	    return true;
	}
	
	public boolean updateInterval(int interval){
		SQLiteDatabase db = this.getWritableDatabase();
	    ContentValues contentValues = new ContentValues();
	    contentValues.put(AppConstants.COLUMN_INTERVAL, interval);
	    db.update(AppConstants.SETTING_TABLE_NAME, contentValues, null, null);
	    return true;
	}
	
	public boolean updateNotification(int notification){
		SQLiteDatabase db = this.getWritableDatabase();
	    ContentValues contentValues = new ContentValues();
	    contentValues.put(AppConstants.COLUMN_CCY, notification);
	    db.update(AppConstants.SETTING_TABLE_NAME, contentValues, null, null);
	    return true;
	}

	public void dropTable(){
		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(AppConstants.DROP_TABLE + AppConstants.SETTING_TABLE_NAME);
	}
	
	public boolean ifExist(){
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cr = db.rawQuery(AppConstants.CHECK_TABLE, new String[]{AppConstants.SETTING_TABLE_NAME});
		if((cr != null) && cr.getCount() > 0){
				return true;
		}
		return false;
	}
	
	public String getQuoteCurrency(){
		if(ifExist()){
			if(numberOfRows() > 0){
				Cursor cr = getSettings();
				if((cr != null) && cr.getCount() > 0){
					cr.moveToFirst();
					return cr.getString(0);
				}
			}
		}
		return null;
	}
	
	public String getMktVenue(){
		if(ifExist()){
			if(numberOfRows() > 0){
				Cursor cr = getSettings();
				if((cr != null) && cr.getCount() > 0){
					cr.moveToFirst();
					return cr.getString(1);
				}
			}
		}
		return null;
	}
	
	public int getInterval(){
		if(ifExist()){
			if(numberOfRows() > 0){
				Cursor cr = getSettings();
				if((cr != null) && cr.getCount() > 0){
					cr.moveToFirst();
					return cr.getInt(2);
				}
			}
		}
		return 1;
	}
	
	public int getNotification(){
		if(ifExist()){
			if(numberOfRows() > 0){
				Cursor cr = getSettings();
				if((cr != null) && cr.getCount() > 0){
					cr.moveToFirst();
					return cr.getInt(3);
				}
			}
		}
		return 0;
	}
		
}
