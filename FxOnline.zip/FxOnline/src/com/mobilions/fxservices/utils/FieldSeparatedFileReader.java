/**
 * Reads files in which fields are separated by a separator.
 */
package com.mobilions.fxservices.utils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;

import android.content.res.AssetManager;
import android.util.Log;

/**
 * @author Shreyas Trivedi
 *
 */
public class FieldSeparatedFileReader {
	
	private String filePath;
	private String separator;
	private BufferedReader read;
	private String[] header;
	private AssetManager assets;
	
	public FieldSeparatedFileReader(String filePath, String separator) throws FileNotFoundException{
		this.filePath = filePath;
		this.separator = separator;
		openFile();
	}
	
	public FieldSeparatedFileReader(Reader in, String separator, AssetManager assets){
		this.separator = separator;
		read = new BufferedReader(in);
		this.assets = assets;
		Log.i("File Reader", "File opened");
	}

	private void openFile() throws FileNotFoundException{
		read = new BufferedReader(new FileReader(filePath));
	}
	
	public String[] getNextLine() throws IOException{
		if(read != null){
			Log.i("File Reader", "Reading next line");
			String line = read.readLine();
			Log.i("File Reader", "Next Line: " + line);
			Log.i("File Reader", "separator: " + separator);
			if(line != null){
				String[] fields = line.split(separator);
				Log.i("File Reader", "Line Contents:" + fields[0]);
				return fields;
			}else{
				return null;
			}
		}
		return null;
	}
	
	public HashMap<String, String> getNextLineWithHeader() throws IOException{
		if(header == null){
			header = getNextLine();
		}
		if(header != null){
			String[] curLine = getNextLine();
			if(curLine != null){
				int headerLen = header.length;
				int lineLen = curLine.length;
				HashMap<String, String> lineMap = new HashMap<String, String>();
				
				if(headerLen == lineLen){
					for(int i=0; i < headerLen; i++){
						lineMap.put(header[i], curLine[i]);
						Log.i("File Reader", "Next Param: " + header[i] + " , " + curLine[i]);
					}
					return lineMap;
				}
			}
		}
		return null;
	}
	
	/*public int countLines(){
	    try {
	    	BufferedReader readFile = new BufferedReader(new InputStreamReader(assets.open(AppConstants.INPUT_FILE_NAME)));
	        char[] c = new char[1024];
	        int count = 0;
	        int readChars = 0;
	        boolean empty = true;
	        while ((readChars = readFile.read(c)) != -1) {
	            empty = false;
	            for (int i = 0; i < readChars; ++i) {
	                if (c[i] == '\n') {
	                    ++count;
	                }
	            }
	        }
	        readFile.close();
	        Log.i("File Count", "Line count in file: " + count);
	        return (count == 0 && empty) ? 1 : count;
	    } catch(Exception e) {
	        e.printStackTrace();
	    }
	    return 1;
	}*/
}
