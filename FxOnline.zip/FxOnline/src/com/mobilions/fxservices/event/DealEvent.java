package com.mobilions.fxservices.event;

public class DealEvent extends FxEvent{
	
	String timestamp;
	String currencyPair;
	double quantity;
	float price;
	String side;
	
	public DealEvent(String timestamp, String currencyPair, double quantity, float price, String side){
		this.timestamp = timestamp;
		this.currencyPair = currencyPair;
		this.quantity = quantity;
		this.price = price;
		this.side = side;
	}
	
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getCurrencyPair() {
		return currencyPair;
	}
	public void setCurrencyPair(String currencyPair) {
		this.currencyPair = currencyPair;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getSide() {
		return side;
	}
	public void setSide(String side) {
		this.side = side;
	}
	
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}

	@Override
	public String toString() {
		return "DealEvent [timestamp=" + timestamp + ", currencyPair=" + currencyPair + ", quantity=" + quantity
				+ ", price=" + price + ", side=" + side + "]";
	}
	
}
