package com.mobilions.fxservices.event;

public abstract class FxEvent implements Cloneable{

}
