package com.mobilions.fxservices.event;

public class QuoteEvent extends FxEvent{
	
	private long timestamp;
	private String currencyPair;
	private String market;
	private float bidRate;
	private float askRate;
	
	public QuoteEvent(long timestamp, String currencyPair, String market, float bidRate, float askRate){
		
		this.timestamp = timestamp;
		this.currencyPair = currencyPair;
		this.market = market;
		this.bidRate = bidRate;
		this.askRate = askRate;
	}
	
	public long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	public String getCurrencyPair() {
		return currencyPair;
	}
	public void setCurrencyPair(String currencyPair) {
		this.currencyPair = currencyPair;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public float getBidRate() {
		return bidRate;
	}
	public void setBidRate(float bidRate) {
		this.bidRate = bidRate;
	}
	public float getAskRate() {
		return askRate;
	}
	public void setAskRate(float askRate) {
		this.askRate = askRate;
	}

	@Override
	public String toString() {
		return "QuoteEvent [timestamp=" + timestamp + ", currencyPair=" + currencyPair + ", market=" + market
				+ ", bidRate=" + bidRate + ", askRate=" + askRate + "]";
	}

}
