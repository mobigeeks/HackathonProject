package com.mobilions.fxservices.eventProcessor;

import com.mobilions.fxservices.event.FxEvent;

public interface FxEventProcessor {
	
	void processEvent(FxEvent event);

}
