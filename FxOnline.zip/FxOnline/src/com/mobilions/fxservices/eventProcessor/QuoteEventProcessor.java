package com.mobilions.fxservices.eventProcessor;

import java.util.Collection;
import java.util.Iterator;
import java.util.logging.Logger;

import com.mobilions.fxservices.event.FxEvent;
import com.mobilions.fxservices.event.QuoteEvent;
import com.mobilions.fxservices.reportdata.CurrencyData;
import com.mobilions.fxservices.reportdata.CurrencyDataManager;
import com.mobilions.fxservices.reportdata.CurrencyDataManagerMap;

public class QuoteEventProcessor implements FxEventProcessor {
	
	private static final Logger logger = Logger.getLogger(QuoteEventProcessor.class.getName());
	String marketToProcess = "AGG";
	String baseCurrency = "USD";
	
	private CurrencyDataManager dataManager = CurrencyDataManagerMap.getInstance();

	@Override
	public void processEvent(FxEvent event) {
		// TODO Auto-generated method stub
		if(event instanceof QuoteEvent){
			QuoteEvent quote = (QuoteEvent) event;
			logger.info("Processing quote event: " + quote.toString());
			if(quote.getMarket() != null && quote.getMarket().equalsIgnoreCase(marketToProcess)){
				if(quote.getCurrencyPair() != null && quote.getCurrencyPair().length() == 6){
					String cur1 = quote.getCurrencyPair().substring(0, 3);
					String cur2 = quote.getCurrencyPair().substring(3, 6);
					
					if(baseCurrency.equalsIgnoreCase(cur2)){
						updateDataSet(cur1, quote.getAskRate(), quote.getBidRate());
						updateDataSet(cur2, 0, 0);
					}else if(baseCurrency.equalsIgnoreCase(cur1)){
						updateDataSet(cur2, 1/quote.getAskRate(), 1/quote.getBidRate());
						updateDataSet(cur1, 0, 0);
					}else{
						logger.info("Currency pair does not have base currency. Filtering the event.");
					}
					print();
				}else{
					logger.info("Invalid currency pair received: " + quote.getCurrencyPair());
				}
				
			}else{
				logger.info("Filtering the event for the market: " + quote.getMarket());
			}
		}else{
			logger.warning("Invalid quote event");
		}
	}
	
	private void updateDataSet(String currency, float askPrice, float bidPrice){
		if(dataManager != null){
			CurrencyData curData;
			if(dataManager.containsCurrency(currency)){
				curData = dataManager.getCurrencyData(currency);
				curData.setAskPrice(askPrice);
				curData.setBidPrice(bidPrice);
				curData.setMarkateMidPrice((bidPrice+askPrice)/2);
			}else{
				curData = new CurrencyData(currency);
				curData.setAskPrice(askPrice);
				curData.setBidPrice(bidPrice);
				curData.setMarkateMidPrice((bidPrice+askPrice)/2);
				dataManager.addCurrencyData(curData);
			}
		}
	}
	
	private void print(){
//		CurrencyData[] values = (CurrencyData[]) dataManager.getAllCurrencies();
//		Iterator<CurrencyData> iterate = values.iterator();
		
//		while(iterate.hasNext()){
//			logger.info(iterate.next().toString());
//		}
	}

}
