package com.mobilions.fxservices.eventProcessor;

import java.util.Collection;
import java.util.Iterator;
import java.util.logging.Logger;

import com.mobilions.fxservices.event.FxEvent;
import com.mobilions.fxservices.event.QuoteEvent;
import com.mobilions.fxservices.reportdata.CurrencyData;
import com.mobilions.fxservices.reportdata.CurrencyDataManager;
import com.mobilions.fxservices.reportdata.CurrencyDataManagerMap;
import com.mobilions.fxservices.utils.Settings;

public class QuoteEventProcessor implements FxEventProcessor {
	
	private static final Logger logger = Logger.getLogger(QuoteEventProcessor.class.getName());
//	private static String marketToProcess = "AGG";
//	private static String baseCurrency = "USD";
	
	private CurrencyDataManager dataManager = CurrencyDataManagerMap.getInstance();

	@Override
	public void processEvent(FxEvent event) {
		// TODO Auto-generated method stub
		if(event instanceof QuoteEvent){
			QuoteEvent quote = (QuoteEvent) event;
			logger.info("Processing quote event: " + quote.toString());
			logger.info("Mkt Venue: " + Settings.mktVenue);
			if((Settings.mktVenue.equalsIgnoreCase("ALL")) || (quote.getMarket() != null && quote.getMarket().equalsIgnoreCase(Settings.mktVenue))){
				if(quote.getCurrencyPair() != null && quote.getCurrencyPair().length() == 6){
					String cur1 = quote.getCurrencyPair().substring(0, 3);
					String cur2 = quote.getCurrencyPair().substring(3, 6);
					
					if(Settings.quoteCurrency.equalsIgnoreCase(cur2)){
						updateDataSet(cur1, quote.getAskRate(), quote.getBidRate(),quote.getTimestamp());
						updateDataSet(cur2, 0, 0,0);
					}else if(Settings.quoteCurrency.equalsIgnoreCase(cur1)){
						updateDataSet(cur2, 1/quote.getAskRate(), 1/quote.getBidRate(),quote.getTimestamp());
						updateDataSet(cur1, 0, 0,0);
					}else{
						logger.info("Currency pair does not have base currency. Filtering the event.");
					}
					print();
				}else{
					logger.info("Invalid currency pair received: " + quote.getCurrencyPair());
				}
				
			}else{
				logger.info("Filtering the event for the market: " + quote.getMarket());
			}
		}else{
			logger.warning("Invalid quote event");
		}
	}
	
	private void updateDataSet(String currency, float askPrice, float bidPrice, long timeStamp){
		if(dataManager != null){
			CurrencyData curData;
			if(dataManager.containsCurrency(currency)){
				curData = dataManager.getCurrencyData(currency);
				curData.setAskPrice(askPrice);
				curData.setBidPrice(bidPrice);
				curData.setMarkateMidPrice((bidPrice+askPrice)/2);
				if(!currency.equalsIgnoreCase(Settings.quoteCurrency)){
					updatePnL(curData, timeStamp);
				}
			}else{
				curData = new CurrencyData(currency);
				curData.setAskPrice(askPrice);
				curData.setBidPrice(bidPrice);
				curData.setMarkateMidPrice((bidPrice+askPrice)/2);
				dataManager.addCurrencyData(curData);
			}
		}
	}
	
	private void updatePnL(CurrencyData curData, long timeStamp){
		curData.setBasePositon(curData.getPosition()*curData.getMarkateMidPrice());
		curData.setPnl(getPnl(curData));
		curData.setLastUpdate(timeStamp);
	}
	
	private void print(){
//		CurrencyData[] values = (CurrencyData[]) dataManager.getAllCurrencies();
//		Iterator<CurrencyData> iterate = values.iterator();
		
//		while(iterate.hasNext()){
//			logger.info(iterate.next().toString());
//		}
	}

//	public static String getBaseCurrency() {
//		return Settings.quoteCurrency;
//	}
//
//	public static void setBaseCurrency(String baseCurrency) {
//		QuoteEventProcessor.baseCurrency = baseCurrency;
//	}
	
	private float getPnl(CurrencyData curData){
		double buyPriceDiff;
		double sellPriceDiff;
		if(curData.getAvgBuyPrice() != 0){
			buyPriceDiff = curData.getMarkateMidPrice() - curData.getAvgBuyPrice();
		}else{
			buyPriceDiff = 0.0;
		}
		
		if(curData.getAvgSellPrice() != 0){
			sellPriceDiff = curData.getAvgSellPrice() - curData.getMarkateMidPrice();
		}else{
			sellPriceDiff = 0.0;
		}
		
		return (float) ((Math.abs(curData.getBasePositon())*(buyPriceDiff + sellPriceDiff))/1000);
	}

}
