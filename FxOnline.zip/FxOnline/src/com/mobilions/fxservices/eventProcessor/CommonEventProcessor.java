package com.mobilions.fxservices.eventProcessor;

import java.util.logging.Logger;

import com.mobilions.fxservices.event.DealEvent;
import com.mobilions.fxservices.event.FxEvent;
import com.mobilions.fxservices.event.QuoteEvent;

public class CommonEventProcessor{
	
	private static final Logger logger = Logger.getLogger(CommonEventProcessor.class.getName());
	private DealEventProcessor dealProcessor;
	private QuoteEventProcessor quoteProcessor;
	
	public CommonEventProcessor(){
		dealProcessor = new DealEventProcessor();
		quoteProcessor = new QuoteEventProcessor();
	}

	public void processEvent(String[] event) {
		// TODO Auto-generated method stub
		if(event != null){
			int noOfParams = event.length;
			if(noOfParams == 6){
				FxEvent newEvent;
				if("quote".equalsIgnoreCase(event[0])){
					newEvent = new QuoteEvent(event[1], event[2], event[3], 
							Float.parseFloat(event[4]), Float.parseFloat(event[5]));
					quoteProcessor.processEvent(newEvent);
				}else{
					newEvent = new DealEvent(event[1], event[2], Double.parseDouble(event[3]), 
							Float.parseFloat(event[4]), event[5]);
					dealProcessor.processEvent(newEvent);
				}
			}else{
				logger.warning("Invalid event received: " + event[0]);
			}
		}
	}

}
