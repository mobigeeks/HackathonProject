package com.mobilions.fxservices.eventProcessor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.logging.Logger;

import com.mobilions.fxservices.event.DealEvent;
import com.mobilions.fxservices.event.FxEvent;
import com.mobilions.fxservices.reportdata.CurrencyData;
import com.mobilions.fxservices.reportdata.CurrencyDataManager;
import com.mobilions.fxservices.reportdata.CurrencyDataManagerMap;

public class DealEventProcessor implements FxEventProcessor{
	
	private static final Logger logger = Logger.getLogger(DealEventProcessor.class.getName());
	
	private ArrayList<DealEvent> dealEvents = new ArrayList<DealEvent>();
	
	private static String baseCurrency = "USD";
	
	private CurrencyDataManager dataManager = CurrencyDataManagerMap.getInstance();

	@Override
	public void processEvent(FxEvent event) {
		// TODO Auto-generated method stub
		if(event instanceof DealEvent){
			DealEvent deal = (DealEvent)event;
			dealEvents.add(deal);
			logger.info("Processing deal event: " + deal.toString());
			if(deal.getCurrencyPair() != null && deal.getCurrencyPair().length() == 6){
				String cur1 = deal.getCurrencyPair().substring(0, 3);
				String cur2 = deal.getCurrencyPair().substring(3, 6);
				
				if(baseCurrency.equalsIgnoreCase(cur2)){
					processNormalDeal(cur1, deal);
					processBaseCurrency(deal.getQuantity()*deal.getPrice(), deal.getSide());
				}else if(baseCurrency.equalsIgnoreCase(cur1)){
					deal.setPrice(1/deal.getPrice());
					processNormalDeal(cur2, deal);
					processBaseCurrency(deal.getQuantity()*deal.getPrice(), deal.getSide());
				}else{
					try {
						DealEvent deal2 = (DealEvent) deal.clone();
						if(dataManager != null){
							if(dataManager.containsCurrency(cur1)){
								CurrencyData cur1Data = dataManager.getCurrencyData(cur1);
								deal.setPrice(cur1Data.getMarkateMidPrice());
								processNormalDeal(cur1, deal);
							}
							if(dataManager.containsCurrency(cur2)){
								CurrencyData cur2Data = dataManager.getCurrencyData(cur2);
								deal2.setQuantity(deal2.getQuantity()*deal2.getPrice());
								deal2.setPrice(cur2Data.getMarkateMidPrice());
								if("B".equalsIgnoreCase(deal2.getSide())){
									deal2.setSide("S");
								}else{
									deal2.setSide("B");
								}
								processNormalDeal(cur2, deal2);
							}
						}
					} catch (CloneNotSupportedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				print();
			}else{
				logger.info("Invalid currency pair received: " + deal.getCurrencyPair());
			}
			
		}else{
			logger.warning("Invalid deal event");
		}
	}
	
	private void processNormalDeal(String currency, DealEvent deal){
		if(dataManager != null){
			CurrencyData curData;
			if(dataManager.containsCurrency(currency)){
				curData = dataManager.getCurrencyData(currency);
			}else{
				curData = new CurrencyData(currency);
				dataManager.addCurrencyData(curData);
			}
			curData.setLastUpdate(deal.getTimestamp());
			if("B".equalsIgnoreCase(deal.getSide())){
				curData.setPosition(curData.getPosition() + deal.getQuantity());
				curData.setBasePositon(curData.getBasePositon() + (deal.getQuantity()*deal.getPrice()));
				curData.setTotalBuyPrice(curData.getTotalBuyPrice() + (deal.getQuantity()*deal.getPrice()));
				curData.setTotalBuyQty(curData.getTotalBuyQty() + deal.getQuantity());
				curData.setAvgBuyPrice(curData.getTotalBuyPrice()/curData.getTotalBuyQty());
			}else{
				curData.setPosition(curData.getPosition() - deal.getQuantity());
				curData.setBasePositon(curData.getBasePositon() - (deal.getQuantity()*deal.getPrice()));
				curData.setTotalSellPrice(curData.getTotalSellPrice() + (deal.getQuantity()*deal.getPrice()));
				curData.setTotalSellQty(curData.getTotalSellQty() + deal.getQuantity());
				curData.setAvgSellPrice(curData.getTotalSellPrice()/curData.getTotalSellQty());
			}
			curData.setPnl(getPnl(curData));
			curData.setBookMidPrice((float) getBookMidPrice(curData.getAvgBuyPrice(), curData.getAvgSellPrice()));
		}
	}
	
	private double getBookMidPrice(double avgBuyPrice, double avgSellPrice){
		if(avgBuyPrice != 0 && avgSellPrice != 0){
			return (avgBuyPrice + avgSellPrice)*0.5;
		}else if(avgBuyPrice != 0){
			return avgBuyPrice;
		}else{
			return avgSellPrice;
		}
	}
	
	private float getPnl(CurrencyData curData){
		double buyPriceDiff;
		double sellPriceDiff;
		if(curData.getAvgBuyPrice() != 0){
			buyPriceDiff = curData.getMarkateMidPrice() - curData.getAvgBuyPrice();
		}else{
			buyPriceDiff = 0.0;
		}
		
		if(curData.getAvgSellPrice() != 0){
			sellPriceDiff = curData.getAvgSellPrice() - curData.getMarkateMidPrice();
		}else{
			sellPriceDiff = 0.0;
		}
		
		return (float) ((Math.abs(curData.getBasePositon())*(buyPriceDiff + sellPriceDiff))/1000);
	}
	
	private void processBaseCurrency(double position, String side){
		if(dataManager != null){
			CurrencyData curData;
			if(dataManager.containsCurrency(baseCurrency)){
				curData = dataManager.getCurrencyData(baseCurrency);
			}else{
				curData = new CurrencyData(baseCurrency);
				dataManager.addCurrencyData(curData);
			}
			if("B".equalsIgnoreCase(side)){
				curData.setPosition(curData.getPosition() - position);
				curData.setBasePositon(curData.getBasePositon() - position);
			}else{
				curData.setPosition(curData.getPosition() + position);
				curData.setBasePositon(curData.getBasePositon() + position);
			}
		}
	}

	private void print(){
//		Collection<CurrencyData> values = (Collection<CurrencyData>) dataManager.getAllCurrencies();
//		Iterator<CurrencyData> iterate = values.iterator();
//		
//		while(iterate.hasNext()){
//			logger.info(iterate.next().toString());
//		}
	}

	public static String getBaseCurrency() {
		return baseCurrency;
	}

	public static void setBaseCurrency(String baseCurrency) {
		DealEventProcessor.baseCurrency = baseCurrency;
	}
}
