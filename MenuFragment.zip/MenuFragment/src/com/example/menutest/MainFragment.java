package com.example.menutest;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.TextView;

public class MainFragment extends Fragment{
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.mainfragment, container, false);

        
        final TextView tv= (TextView) rootView.findViewById(R.id.textView1);
        OnClickListener l=new OnClickListener() {
			
			@Override
			public void onClick(View v) {
			tv.setText("clicked");				
			}
		};
		tv.setOnClickListener(l);
        return rootView;
    }

}
